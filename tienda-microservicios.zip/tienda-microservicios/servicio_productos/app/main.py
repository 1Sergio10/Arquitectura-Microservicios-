import logging
import os
import time
from uuid import UUID, uuid4

from fastapi import FastAPI, HTTPException, Query, Request, status

from .models import Producto, ProductoCrear
from .repository import SkuDuplicado, crear_repositorio

NOMBRE_SERVICIO = "servicio-productos"

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s [%(name)s] %(message)s")
log = logging.getLogger(NOMBRE_SERVICIO)

app = FastAPI(
    title="Servicio de Productos",
    version="1.0.0",
    description="Administra el catálogo de la tienda virtual. Es el único dueño de los datos de productos.",
)
app.state.repo = crear_repositorio(con_datos_iniciales=os.getenv("CARGAR_DATOS_INICIALES", "1") == "1")


@app.middleware("http")
async def trazabilidad(request: Request, call_next):
    # Se reutiliza el X-Request-ID que llega de otro servicio para poder seguir
    # una misma operación en los logs de los tres servicios.
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    inicio = time.perf_counter()
    respuesta = await call_next(request)
    duracion_ms = (time.perf_counter() - inicio) * 1000
    respuesta.headers["X-Request-ID"] = request_id
    log.info("%s %s -> %s (%.1f ms) rid=%s", request.method, request.url.path, respuesta.status_code, duracion_ms, request_id)
    return respuesta


@app.get("/health", tags=["operación"])
def health() -> dict:
    return {"servicio": NOMBRE_SERVICIO, "estado": "ok"}


@app.get("/productos", response_model=list[Producto], tags=["productos"])
def listar_productos(
    categoria: str | None = None,
    limite: int = Query(50, ge=1, le=200),
    desde: int = Query(0, ge=0),
) -> list[Producto]:
    return app.state.repo.listar(categoria=categoria, limite=limite, desde=desde)


@app.get("/productos/{producto_id}", response_model=Producto, tags=["productos"])
def obtener_producto(producto_id: UUID) -> Producto:
    producto = app.state.repo.obtener(producto_id)
    if producto is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail=f"Producto {producto_id} no existe")
    return producto


@app.post("/productos", response_model=Producto, status_code=status.HTTP_201_CREATED, tags=["productos"])
def registrar_producto(datos: ProductoCrear) -> Producto:
    try:
        return app.state.repo.agregar(datos)
    except SkuDuplicado:
        raise HTTPException(status.HTTP_409_CONFLICT, detail=f"Ya existe un producto con SKU {datos.sku}")
