"""Almacenamiento en memoria del catálogo.

El taller pide listas en memoria. El repositorio esconde ese detalle detrás de una
interfaz pequeña, así cambiar a PostgreSQL más adelante no toca los endpoints.
"""
from datetime import datetime, timezone
from threading import Lock
from uuid import UUID, uuid4

from .models import Producto, ProductoCrear


class SkuDuplicado(Exception):
    pass


class RepositorioProductos:
    def __init__(self) -> None:
        self._items: dict[UUID, Producto] = {}
        self._lock = Lock()

    def agregar(self, datos: ProductoCrear) -> Producto:
        with self._lock:
            if any(p.sku == datos.sku for p in self._items.values()):
                raise SkuDuplicado(datos.sku)
            producto = Producto(id=uuid4(), creado_en=datetime.now(timezone.utc), **datos.model_dump())
            self._items[producto.id] = producto
            return producto

    def obtener(self, producto_id: UUID) -> Producto | None:
        return self._items.get(producto_id)

    def listar(self, categoria: str | None = None, limite: int = 50, desde: int = 0) -> list[Producto]:
        productos = sorted(self._items.values(), key=lambda p: p.creado_en)
        if categoria:
            productos = [p for p in productos if p.categoria.lower() == categoria.lower()]
        return productos[desde : desde + limite]


CATALOGO_INICIAL = [
    ProductoCrear(sku="LAP-001", nombre="Portátil 14 pulgadas Ryzen 7", categoria="portatiles", precio=2_899_000, stock=12),
    ProductoCrear(sku="MON-027", nombre="Monitor 27 pulgadas QHD", categoria="monitores", precio=1_150_000, stock=20),
    ProductoCrear(sku="TEC-MEC", nombre="Teclado mecánico inalámbrico", categoria="perifericos", precio=389_000, stock=40),
]


def crear_repositorio(con_datos_iniciales: bool = True) -> RepositorioProductos:
    repo = RepositorioProductos()
    if con_datos_iniciales:
        for producto in CATALOGO_INICIAL:
            repo.agregar(producto)
    return repo
