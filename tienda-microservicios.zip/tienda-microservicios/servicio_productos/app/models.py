from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class ProductoCrear(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    sku: str = Field(min_length=3, max_length=30, pattern=r"^[A-Z0-9-]+$", examples=["LAP-001"])
    nombre: str = Field(min_length=2, max_length=120, examples=["Portátil 14 pulgadas"])
    categoria: str = Field(min_length=2, max_length=50, examples=["portatiles"])
    # Precio en pesos colombianos (COP). Se usa entero para evitar errores de redondeo con float.
    precio: int = Field(gt=0, le=100_000_000, examples=[2_899_000])
    stock: int = Field(ge=0, le=1_000_000, examples=[15])


class Producto(ProductoCrear):
    id: UUID
    creado_en: datetime
