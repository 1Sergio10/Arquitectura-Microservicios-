import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.repository import crear_repositorio


@pytest.fixture
def api():
    app.state.repo = crear_repositorio(con_datos_iniciales=False)
    return TestClient(app)


NUEVO = {"sku": "AUD-BT5", "nombre": "Audífonos Bluetooth", "categoria": "audio", "precio": 249000, "stock": 30}


def test_registrar_y_consultar(api):
    creado = api.post("/productos", json=NUEVO)
    assert creado.status_code == 201
    producto_id = creado.json()["id"]

    consulta = api.get(f"/productos/{producto_id}")
    assert consulta.status_code == 200
    assert consulta.json()["sku"] == "AUD-BT5"


def test_sku_duplicado_devuelve_409(api):
    api.post("/productos", json=NUEVO)
    assert api.post("/productos", json=NUEVO).status_code == 409


@pytest.mark.parametrize("campo, valor", [("precio", 0), ("precio", -5), ("stock", -1), ("sku", "minúscula")])
def test_validacion_de_datos(api, campo, valor):
    assert api.post("/productos", json={**NUEVO, campo: valor}).status_code == 422


def test_rechaza_campos_desconocidos(api):
    assert api.post("/productos", json={**NUEVO, "descuento": 50}).status_code == 422


def test_producto_inexistente_404(api):
    assert api.get("/productos/00000000-0000-0000-0000-000000000000").status_code == 404


def test_filtrar_por_categoria(api):
    api.post("/productos", json=NUEVO)
    api.post("/productos", json={**NUEVO, "sku": "MON-24", "categoria": "monitores"})
    resultado = api.get("/productos", params={"categoria": "AUDIO"}).json()
    assert [p["sku"] for p in resultado] == ["AUD-BT5"]


def test_propaga_request_id(api):
    respuesta = api.get("/health", headers={"X-Request-ID": "abc-123"})
    assert respuesta.headers["X-Request-ID"] == "abc-123"
