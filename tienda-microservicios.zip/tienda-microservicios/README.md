# Tienda virtual con microservicios

Tres servicios REST independientes en FastAPI: **productos**, **clientes** y **pedidos**.
Cada uno es dueño de sus datos, corre en su propio proceso o contenedor y puede apagarse sin tumbar a los demás.

| Servicio  | Puerto | Responsabilidad                         | Documentación              |
|-----------|--------|------------------------------------------|----------------------------|
| productos | 8001   | Catálogo: consultar y registrar          | http://localhost:8001/docs |
| clientes  | 8002   | Registrar y consultar clientes           | http://localhost:8002/docs |
| pedidos   | 8003   | Registrar pedidos y gestionar su estado  | http://localhost:8003/docs |

## Ejecutar

Con Docker:

```bash
docker compose up --build
docker compose stop productos     # simular la caída de un servicio
docker compose start productos
```

Sin Docker (Python 3.11 o superior):

```bash
pip install -r servicio_pedidos/requirements.txt -r requirements-dev.txt
./scripts/iniciar.sh
python scripts/prueba_tolerancia.py   # flujo completo + caída y recuperación de productos
./scripts/detener.sh
```

## Pruebas automáticas

Cada servicio tiene su propia suite y se prueba aislado:

```bash
cd servicio_productos && python -m pytest -q
cd servicio_clientes  && python -m pytest -q
cd servicio_pedidos   && python -m pytest -q
```

## Endpoints

**Productos**: `GET /productos?categoria=&limite=&desde=`, `GET /productos/{id}`, `POST /productos`

**Clientes**: `POST /clientes`, `GET /clientes`, `GET /clientes/{id}`, `GET /clientes/{id}/resumen` (vista para otros servicios, sin documento)

**Pedidos**: `POST /pedidos` (acepta encabezado `Idempotency-Key`), `GET /pedidos?cliente_id=&estado=`, `GET /pedidos/{id}`, `GET /pedidos/{id}/estado`, `PATCH /pedidos/{id}/estado`, `GET /health/dependencias`

Todos exponen `GET /health`.

## Decisiones de diseño

- **Base de datos por servicio.** Ningún servicio lee los datos de otro; solo se comunican por HTTP.
- **Copia de datos en el pedido.** El pedido guarda nombre y precio del producto al momento de la compra, así consultarlo no depende de productos y un cambio de precio no altera pedidos viejos.
- **Timeout corto, reintentos con espera exponencial y circuit breaker** en las llamadas de pedidos hacia productos y clientes. Si una dependencia cae, pedidos responde `503` con `Retry-After` en lugar de quedarse colgado.
- **Idempotencia** en la creación de pedidos para que un reintento del cliente no genere pedidos duplicados.
- **Máquina de estados** para el pedido: `CREADO → PAGADO → ENVIADO → ENTREGADO`, con `CANCELADO` desde `CREADO` o `PAGADO`.
- **Trazabilidad** con `X-Request-ID`, que se propaga entre servicios y aparece en los logs.
- **Contenedores sin root** y con `HEALTHCHECK`.

## Limitaciones conocidas

- Los datos viven en memoria: al reiniciar un servicio se pierden.
- La validación de stock es de lectura; no se reserva ni descuenta stock. En producción se haría con un patrón saga o con eventos.
- No hay autenticación entre servicios ni hacia el usuario.
