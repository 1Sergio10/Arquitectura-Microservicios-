"""Pruebas del servicio de pedidos sin levantar los otros servicios.

httpx.MockTransport reemplaza la red: así se simula que productos o clientes
responden, no existen o están caídos, de forma determinista.
"""
from uuid import uuid4

import httpx
import pytest
from fastapi.testclient import TestClient

from app.main import Integraciones, app
from app.repository import RepositorioPedidos
from app.resiliencia import CircuitBreaker, ClienteServicio

CLIENTE_ID = str(uuid4())
PRODUCTO_ID = str(uuid4())
PRODUCTO = {"id": PRODUCTO_ID, "sku": "LAP-001", "nombre": "Portátil", "categoria": "portatiles",
            "precio": 2_000_000, "stock": 5, "creado_en": "2026-10-29T00:00:00Z"}


class Red:
    """Estado simulado de los servicios vecinos."""

    def __init__(self) -> None:
        self.productos_caido = False
        self.llamadas_productos = 0

    def __call__(self, request: httpx.Request) -> httpx.Response:
        if request.url.host == "productos":
            self.llamadas_productos += 1
            if self.productos_caido:
                raise httpx.ConnectError("conexión rechazada", request=request)
            if request.url.path == f"/productos/{PRODUCTO_ID}":
                return httpx.Response(200, json=PRODUCTO)
            return httpx.Response(404, json={"detail": "no existe"})
        if request.url.path == f"/clientes/{CLIENTE_ID}/resumen":
            return httpx.Response(200, json={"id": CLIENTE_ID, "nombre": "Laura", "email": "l@c.co"})
        return httpx.Response(404, json={"detail": "no existe"})


@pytest.fixture
def red():
    return Red()


@pytest.fixture
def api(red):
    http = httpx.AsyncClient(transport=httpx.MockTransport(red))
    app.state.repo = RepositorioPedidos()
    app.state.integraciones = Integraciones(
        productos=ClienteServicio("productos", "http://productos", http, CircuitBreaker("productos", umbral_fallos=2),
                                  reintentos=1, espera_base=0),
        clientes=ClienteServicio("clientes", "http://clientes", http, CircuitBreaker("clientes"), espera_base=0),
    )
    with TestClient(app) as cliente:
        yield cliente
    del app.state.integraciones


def pedido(cantidad=2, producto_id=PRODUCTO_ID, cliente_id=CLIENTE_ID):
    return {"cliente_id": cliente_id, "items": [{"producto_id": producto_id, "cantidad": cantidad}]}


def test_crea_pedido_con_copia_del_precio(api):
    respuesta = api.post("/pedidos", json=pedido(cantidad=2))
    assert respuesta.status_code == 201
    cuerpo = respuesta.json()
    assert cuerpo["total"] == 4_000_000
    assert cuerpo["lineas"][0]["nombre"] == "Portátil"
    assert cuerpo["estado"] == "CREADO"


def test_cliente_inexistente_422(api):
    assert api.post("/pedidos", json=pedido(cliente_id=str(uuid4()))).status_code == 422


def test_producto_inexistente_422(api):
    assert api.post("/pedidos", json=pedido(producto_id=str(uuid4()))).status_code == 422


def test_stock_insuficiente_409(api):
    assert api.post("/pedidos", json=pedido(cantidad=6)).status_code == 409


def test_productos_repetidos_en_el_pedido_422(api):
    cuerpo = pedido()
    cuerpo["items"].append(cuerpo["items"][0])
    assert api.post("/pedidos", json=cuerpo).status_code == 422


def test_idempotencia_evita_duplicados(api):
    clave = {"Idempotency-Key": "compra-001"}
    primero = api.post("/pedidos", json=pedido(), headers=clave)
    segundo = api.post("/pedidos", json=pedido(), headers=clave)
    assert (primero.status_code, segundo.status_code) == (201, 200)
    assert primero.json()["id"] == segundo.json()["id"]
    assert len(api.get("/pedidos").json()) == 1


def test_productos_caido_responde_503_y_consultas_siguen(api, red):
    existente = api.post("/pedidos", json=pedido()).json()
    red.productos_caido = True

    respuesta = api.post("/pedidos", json=pedido())
    assert respuesta.status_code == 503
    assert respuesta.json()["servicio"] == "productos"
    assert "Retry-After" in respuesta.headers

    # Los pedidos ya registrados se consultan sin tocar productos.
    assert api.get(f"/pedidos/{existente['id']}").status_code == 200
    assert api.get(f"/pedidos/{existente['id']}/estado").json()["estado"] == "CREADO"


def test_circuito_abierto_no_llama_a_productos(api, red):
    red.productos_caido = True
    api.post("/pedidos", json=pedido())
    api.post("/pedidos", json=pedido())  # segundo fallo: el circuito se abre
    llamadas_antes = red.llamadas_productos

    assert api.post("/pedidos", json=pedido()).status_code == 503
    assert red.llamadas_productos == llamadas_antes
    assert api.get("/health/dependencias").json()["dependencias"]["productos"] == "ABIERTO"


@pytest.mark.parametrize("secuencia, esperado", [
    (["PAGADO", "ENVIADO", "ENTREGADO"], [200, 200, 200]),
    (["ENVIADO"], [409]),
    (["CANCELADO", "PAGADO"], [200, 409]),
])
def test_transiciones_de_estado(api, secuencia, esperado):
    pedido_id = api.post("/pedidos", json=pedido()).json()["id"]
    codigos = [api.patch(f"/pedidos/{pedido_id}/estado", json={"estado": e}).status_code for e in secuencia]
    assert codigos == esperado
