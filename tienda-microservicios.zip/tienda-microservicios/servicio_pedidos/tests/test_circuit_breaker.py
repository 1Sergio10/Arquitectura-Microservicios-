from app.resiliencia import CircuitBreaker, EstadoCircuito


class Reloj:
    def __init__(self) -> None:
        self.t = 0.0

    def __call__(self) -> float:
        return self.t


def test_ciclo_completo_del_circuito():
    reloj = Reloj()
    cb = CircuitBreaker("x", umbral_fallos=3, segundos_abierto=10, reloj=reloj)

    cb.registrar_fallo()
    cb.registrar_fallo()
    assert cb.estado == EstadoCircuito.CERRADO

    cb.registrar_fallo()
    assert cb.estado == EstadoCircuito.ABIERTO
    assert not cb.permite_llamada()

    reloj.t = 10
    assert cb.estado == EstadoCircuito.SEMI_ABIERTO
    assert cb.permite_llamada()

    cb.registrar_exito()
    assert cb.estado == EstadoCircuito.CERRADO


def test_fallo_en_semi_abierto_reabre_de_inmediato():
    reloj = Reloj()
    cb = CircuitBreaker("x", umbral_fallos=1, segundos_abierto=5, reloj=reloj)
    cb.registrar_fallo()
    reloj.t = 6
    assert cb.estado == EstadoCircuito.SEMI_ABIERTO

    cb.registrar_fallo()
    assert cb.estado == EstadoCircuito.ABIERTO
    assert cb.segundos_para_reintentar() == 5
