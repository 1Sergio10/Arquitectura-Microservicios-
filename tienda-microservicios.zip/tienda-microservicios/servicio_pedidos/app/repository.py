from datetime import datetime, timezone
from threading import Lock
from uuid import UUID

from .models import TRANSICIONES, EstadoPedido, Pedido


class TransicionInvalida(Exception):
    def __init__(self, actual: EstadoPedido, nuevo: EstadoPedido) -> None:
        super().__init__(f"{actual.value} -> {nuevo.value}")
        self.actual = actual
        self.nuevo = nuevo


class RepositorioPedidos:
    def __init__(self) -> None:
        self._items: dict[UUID, Pedido] = {}
        self._por_clave_idempotencia: dict[str, UUID] = {}
        self._lock = Lock()

    def guardar(self, pedido: Pedido, clave_idempotencia: str | None = None) -> Pedido:
        with self._lock:
            self._items[pedido.id] = pedido
            if clave_idempotencia:
                self._por_clave_idempotencia[clave_idempotencia] = pedido.id
            return pedido

    def buscar_por_clave(self, clave: str) -> Pedido | None:
        pedido_id = self._por_clave_idempotencia.get(clave)
        return self._items.get(pedido_id) if pedido_id else None

    def obtener(self, pedido_id: UUID) -> Pedido | None:
        return self._items.get(pedido_id)

    def listar(self, cliente_id: UUID | None = None, estado: EstadoPedido | None = None) -> list[Pedido]:
        pedidos = sorted(self._items.values(), key=lambda p: p.creado_en)
        if cliente_id:
            pedidos = [p for p in pedidos if p.cliente_id == cliente_id]
        if estado:
            pedidos = [p for p in pedidos if p.estado == estado]
        return pedidos

    def cambiar_estado(self, pedido_id: UUID, nuevo: EstadoPedido) -> Pedido | None:
        with self._lock:
            pedido = self._items.get(pedido_id)
            if pedido is None:
                return None
            if nuevo not in TRANSICIONES[pedido.estado]:
                raise TransicionInvalida(pedido.estado, nuevo)
            actualizado = pedido.model_copy(update={"estado": nuevo, "actualizado_en": datetime.now(timezone.utc)})
            self._items[pedido_id] = actualizado
            return actualizado
