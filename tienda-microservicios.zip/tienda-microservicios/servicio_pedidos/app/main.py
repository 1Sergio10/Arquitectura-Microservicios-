import asyncio
import logging
import os
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from uuid import UUID, uuid4

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response, status
from fastapi.responses import JSONResponse

from .models import CambioEstado, EstadoPedido, EstadoRespuesta, LineaPedido, Pedido, PedidoCrear
from .repository import RepositorioPedidos, TransicionInvalida
from .resiliencia import CircuitBreaker, ClienteServicio, DependenciaNoDisponible, RecursoNoEncontrado

NOMBRE_SERVICIO = "servicio-pedidos"

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s [%(name)s] %(message)s")
log = logging.getLogger(NOMBRE_SERVICIO)


@dataclass
class Integraciones:
    productos: ClienteServicio
    clientes: ClienteServicio


def construir_integraciones(http: httpx.AsyncClient) -> Integraciones:
    return Integraciones(
        productos=ClienteServicio("productos", os.getenv("PRODUCTOS_URL", "http://localhost:8001"), http,
                                  CircuitBreaker("productos")),
        clientes=ClienteServicio("clientes", os.getenv("CLIENTES_URL", "http://localhost:8002"), http,
                                 CircuitBreaker("clientes")),
    )


@asynccontextmanager
async def ciclo_de_vida(app: FastAPI):
    # Un solo AsyncClient reutiliza conexiones. El timeout es corto a propósito:
    # es preferible fallar rápido que dejar al usuario esperando 30 s.
    timeout = httpx.Timeout(float(os.getenv("TIMEOUT_DEPENDENCIAS", "2.0")), connect=1.0)
    async with httpx.AsyncClient(timeout=timeout) as http:
        if not hasattr(app.state, "integraciones"):
            app.state.integraciones = construir_integraciones(http)
        yield


app = FastAPI(
    title="Servicio de Pedidos",
    version="1.0.0",
    description="Registra pedidos y gestiona su estado. Consulta a productos y clientes solo al crear un pedido.",
    lifespan=ciclo_de_vida,
)
app.state.repo = RepositorioPedidos()


def integraciones(request: Request) -> Integraciones:
    return request.app.state.integraciones


@app.middleware("http")
async def trazabilidad(request: Request, call_next):
    request.state.request_id = request.headers.get("X-Request-ID") or str(uuid4())
    inicio = time.perf_counter()
    respuesta = await call_next(request)
    duracion_ms = (time.perf_counter() - inicio) * 1000
    respuesta.headers["X-Request-ID"] = request.state.request_id
    log.info("%s %s -> %s (%.1f ms) rid=%s", request.method, request.url.path, respuesta.status_code,
             duracion_ms, request.state.request_id)
    return respuesta


@app.exception_handler(DependenciaNoDisponible)
async def dependencia_caida(_: Request, error: DependenciaNoDisponible) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        headers={"Retry-After": str(error.reintentar_en)},
        content={
            "error": "dependencia_no_disponible",
            "servicio": error.servicio,
            "mensaje": f"El servicio de {error.servicio} no responde. No se pueden crear pedidos por ahora; "
                       "la consulta de pedidos existentes sigue disponible.",
        },
    )


@app.get("/health", tags=["operación"])
def health() -> dict:
    """Liveness: responde si el proceso está vivo. No depende de otros servicios."""
    return {"servicio": NOMBRE_SERVICIO, "estado": "ok"}


@app.get("/health/dependencias", tags=["operación"])
def health_dependencias(deps: Integraciones = Depends(integraciones)) -> dict:
    return {
        "servicio": NOMBRE_SERVICIO,
        "dependencias": {
            "productos": deps.productos.breaker.estado.value,
            "clientes": deps.clientes.breaker.estado.value,
        },
    }


@app.post("/pedidos", response_model=Pedido, status_code=status.HTTP_201_CREATED, tags=["pedidos"])
async def registrar_pedido(
    datos: PedidoCrear,
    request: Request,
    response: Response,
    deps: Integraciones = Depends(integraciones),
    idempotency_key: str | None = Header(default=None, max_length=100),
) -> Pedido:
    repo: RepositorioPedidos = request.app.state.repo

    # Si el cliente reintenta (p. ej. por un timeout de red), no se crea un pedido duplicado.
    if idempotency_key and (previo := repo.buscar_por_clave(idempotency_key)):
        response.status_code = status.HTTP_200_OK
        return previo

    rid = request.state.request_id
    try:
        cliente = await deps.clientes.obtener(f"/clientes/{datos.cliente_id}/resumen", rid)
    except RecursoNoEncontrado:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, detail=f"El cliente {datos.cliente_id} no existe")

    async def consultar(producto_id: UUID) -> dict:
        try:
            return await deps.productos.obtener(f"/productos/{producto_id}", rid)
        except RecursoNoEncontrado:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, detail=f"El producto {producto_id} no existe")

    productos = await asyncio.gather(*(consultar(item.producto_id) for item in datos.items))

    lineas = []
    for item, producto in zip(datos.items, productos):
        if producto["stock"] < item.cantidad:
            raise HTTPException(
                status.HTTP_409_CONFLICT,
                detail=f"Stock insuficiente para {producto['sku']}: disponible {producto['stock']}, solicitado {item.cantidad}",
            )
        lineas.append(LineaPedido(
            producto_id=item.producto_id, sku=producto["sku"], nombre=producto["nombre"],
            precio_unitario=producto["precio"], cantidad=item.cantidad,
            subtotal=producto["precio"] * item.cantidad,
        ))

    ahora = datetime.now(timezone.utc)
    pedido = Pedido(
        id=uuid4(), cliente_id=datos.cliente_id, cliente_nombre=cliente["nombre"], lineas=lineas,
        total=sum(linea.subtotal for linea in lineas), estado=EstadoPedido.CREADO,
        creado_en=ahora, actualizado_en=ahora,
    )
    return repo.guardar(pedido, idempotency_key)


@app.get("/pedidos", response_model=list[Pedido], tags=["pedidos"])
def listar_pedidos(request: Request, cliente_id: UUID | None = None, estado: EstadoPedido | None = None) -> list[Pedido]:
    return request.app.state.repo.listar(cliente_id=cliente_id, estado=estado)


def _buscar(request: Request, pedido_id: UUID) -> Pedido:
    pedido = request.app.state.repo.obtener(pedido_id)
    if pedido is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail=f"Pedido {pedido_id} no existe")
    return pedido


@app.get("/pedidos/{pedido_id}", response_model=Pedido, tags=["pedidos"])
def obtener_pedido(pedido_id: UUID, request: Request) -> Pedido:
    return _buscar(request, pedido_id)


@app.get("/pedidos/{pedido_id}/estado", response_model=EstadoRespuesta, tags=["pedidos"])
def consultar_estado(pedido_id: UUID, request: Request) -> EstadoRespuesta:
    pedido = _buscar(request, pedido_id)
    return EstadoRespuesta(pedido_id=pedido.id, estado=pedido.estado, actualizado_en=pedido.actualizado_en)


@app.patch("/pedidos/{pedido_id}/estado", response_model=EstadoRespuesta, tags=["pedidos"])
def cambiar_estado(pedido_id: UUID, cambio: CambioEstado, request: Request) -> EstadoRespuesta:
    try:
        pedido = request.app.state.repo.cambiar_estado(pedido_id, cambio.estado)
    except TransicionInvalida as error:
        raise HTTPException(status.HTTP_409_CONFLICT,
                            detail=f"No se puede pasar de {error.actual.value} a {error.nuevo.value}")
    if pedido is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail=f"Pedido {pedido_id} no existe")
    return EstadoRespuesta(pedido_id=pedido.id, estado=pedido.estado, actualizado_en=pedido.actualizado_en)
