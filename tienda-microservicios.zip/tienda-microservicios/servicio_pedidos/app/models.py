from datetime import datetime
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator


class EstadoPedido(str, Enum):
    CREADO = "CREADO"
    PAGADO = "PAGADO"
    ENVIADO = "ENVIADO"
    ENTREGADO = "ENTREGADO"
    CANCELADO = "CANCELADO"


# Transiciones permitidas. Cualquier otra se rechaza con 409.
TRANSICIONES: dict[EstadoPedido, set[EstadoPedido]] = {
    EstadoPedido.CREADO: {EstadoPedido.PAGADO, EstadoPedido.CANCELADO},
    EstadoPedido.PAGADO: {EstadoPedido.ENVIADO, EstadoPedido.CANCELADO},
    EstadoPedido.ENVIADO: {EstadoPedido.ENTREGADO},
    EstadoPedido.ENTREGADO: set(),
    EstadoPedido.CANCELADO: set(),
}


class ItemSolicitado(BaseModel):
    model_config = ConfigDict(extra="forbid")

    producto_id: UUID
    cantidad: int = Field(ge=1, le=100)


class PedidoCrear(BaseModel):
    model_config = ConfigDict(extra="forbid")

    cliente_id: UUID
    items: list[ItemSolicitado] = Field(min_length=1, max_length=20)

    @field_validator("items")
    @classmethod
    def sin_productos_repetidos(cls, items: list[ItemSolicitado]) -> list[ItemSolicitado]:
        ids = [item.producto_id for item in items]
        if len(ids) != len(set(ids)):
            raise ValueError("Cada producto debe aparecer una sola vez; use 'cantidad' para repetirlo")
        return items


class LineaPedido(BaseModel):
    """Copia del producto en el momento de la compra.

    Guardar nombre y precio aquí (en lugar de solo el id) hace que consultar un pedido
    no dependa del servicio de productos y que un cambio de precio posterior no altere
    pedidos ya registrados.
    """

    producto_id: UUID
    sku: str
    nombre: str
    precio_unitario: int
    cantidad: int
    subtotal: int


class Pedido(BaseModel):
    id: UUID
    cliente_id: UUID
    cliente_nombre: str
    lineas: list[LineaPedido]
    total: int
    estado: EstadoPedido
    creado_en: datetime
    actualizado_en: datetime


class CambioEstado(BaseModel):
    model_config = ConfigDict(extra="forbid")

    estado: EstadoPedido


class EstadoRespuesta(BaseModel):
    pedido_id: UUID
    estado: EstadoPedido
    actualizado_en: datetime
