"""Llamadas HTTP a otros servicios con timeout, reintentos y circuit breaker.

Sin esto, si productos se cae, cada pedido esperaría el timeout completo y los hilos
de pedidos se acumularían hasta tumbarlo también (fallo en cascada). El breaker corta
las llamadas mientras la dependencia está caída y responde de inmediato con 503.
"""
import asyncio
import logging
import time
from enum import Enum
from typing import Callable

import httpx

log = logging.getLogger("servicio-pedidos.resiliencia")


class EstadoCircuito(str, Enum):
    CERRADO = "CERRADO"          # todo normal, las llamadas pasan
    ABIERTO = "ABIERTO"          # dependencia caída, no se llama
    SEMI_ABIERTO = "SEMI_ABIERTO"  # se deja pasar una llamada de prueba


class CircuitBreaker:
    def __init__(self, nombre: str, umbral_fallos: int = 3, segundos_abierto: float = 15.0,
                 reloj: Callable[[], float] = time.monotonic) -> None:
        self.nombre = nombre
        self.umbral_fallos = umbral_fallos
        self.segundos_abierto = segundos_abierto
        self._reloj = reloj
        self._fallos = 0
        self._abierto_desde: float | None = None

    @property
    def estado(self) -> EstadoCircuito:
        if self._abierto_desde is None:
            return EstadoCircuito.CERRADO
        if self._reloj() - self._abierto_desde >= self.segundos_abierto:
            return EstadoCircuito.SEMI_ABIERTO
        return EstadoCircuito.ABIERTO

    def permite_llamada(self) -> bool:
        return self.estado != EstadoCircuito.ABIERTO

    def segundos_para_reintentar(self) -> int:
        if self._abierto_desde is None:
            return 0
        restante = self.segundos_abierto - (self._reloj() - self._abierto_desde)
        return max(1, int(restante + 0.999))

    def registrar_exito(self) -> None:
        if self._abierto_desde is not None:
            log.info("Circuito %s se cierra: la dependencia respondió", self.nombre)
        self._fallos = 0
        self._abierto_desde = None

    def registrar_fallo(self) -> None:
        self._fallos += 1
        if self.estado == EstadoCircuito.SEMI_ABIERTO or self._fallos >= self.umbral_fallos:
            if self.estado != EstadoCircuito.ABIERTO:
                log.warning("Circuito %s se abre tras %d fallos", self.nombre, self._fallos)
            self._abierto_desde = self._reloj()


class DependenciaNoDisponible(Exception):
    def __init__(self, servicio: str, reintentar_en: int) -> None:
        super().__init__(servicio)
        self.servicio = servicio
        self.reintentar_en = reintentar_en


class RecursoNoEncontrado(Exception):
    pass


class ClienteServicio:
    """Cliente HTTP hacia un servicio vecino. Solo hace GET, que es idempotente
    y por eso se puede reintentar sin riesgo de duplicar datos."""

    def __init__(self, nombre: str, url_base: str, http: httpx.AsyncClient, breaker: CircuitBreaker,
                 reintentos: int = 2, espera_base: float = 0.15) -> None:
        self.nombre = nombre
        self.url_base = url_base.rstrip("/")
        self.http = http
        self.breaker = breaker
        self.reintentos = reintentos
        self.espera_base = espera_base

    async def obtener(self, ruta: str, request_id: str | None = None) -> dict:
        if not self.breaker.permite_llamada():
            raise DependenciaNoDisponible(self.nombre, self.breaker.segundos_para_reintentar())

        encabezados = {"X-Request-ID": request_id} if request_id else {}
        for intento in range(self.reintentos + 1):
            try:
                respuesta = await self.http.get(f"{self.url_base}{ruta}", headers=encabezados)
            except (httpx.ConnectError, httpx.TimeoutException, httpx.RemoteProtocolError) as error:
                log.warning("%s intento %d falló: %s", self.nombre, intento + 1, type(error).__name__)
            else:
                if respuesta.status_code < 500:
                    self.breaker.registrar_exito()
                    if respuesta.status_code == 404:
                        raise RecursoNoEncontrado(ruta)
                    respuesta.raise_for_status()
                    return respuesta.json()
                log.warning("%s intento %d respondió %d", self.nombre, intento + 1, respuesta.status_code)

            if intento < self.reintentos:
                await asyncio.sleep(self.espera_base * (2 ** intento))

        self.breaker.registrar_fallo()
        raise DependenciaNoDisponible(self.nombre, self.breaker.segundos_para_reintentar() or 5)
