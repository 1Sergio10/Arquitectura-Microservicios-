#!/usr/bin/env bash
# Levanta los tres servicios como procesos separados (sin Docker).
# Uso: ./scripts/iniciar.sh            -> los tres
#      ./scripts/iniciar.sh productos  -> solo uno (p. ej. para volver a encenderlo)
set -euo pipefail

RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$RAIZ/logs"

declare -A PUERTOS=([productos]=8001 [clientes]=8002 [pedidos]=8003)
SERVICIOS=("${@:-productos clientes pedidos}")

for servicio in ${SERVICIOS[@]}; do
  puerto=${PUERTOS[$servicio]}
  (
    cd "$RAIZ/servicio_$servicio"
    nohup python -m uvicorn app.main:app --port "$puerto" > "$RAIZ/logs/$servicio.log" 2>&1 &
    echo $! > "$RAIZ/logs/$servicio.pid"
  )
  echo "servicio-$servicio -> http://localhost:$puerto/docs (pid $(cat "$RAIZ/logs/$servicio.pid"))"
done
