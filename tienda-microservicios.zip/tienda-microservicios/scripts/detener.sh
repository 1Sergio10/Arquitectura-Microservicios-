#!/usr/bin/env bash
# Detiene uno o todos los servicios. Uso: ./scripts/detener.sh [productos|clientes|pedidos]
set -euo pipefail

RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
SERVICIOS=("${@:-productos clientes pedidos}")

for servicio in ${SERVICIOS[@]}; do
  archivo="$RAIZ/logs/$servicio.pid"
  if [[ -f "$archivo" ]]; then
    kill "$(cat "$archivo")" 2>/dev/null && echo "servicio-$servicio detenido" || echo "servicio-$servicio ya estaba detenido"
    rm -f "$archivo"
  fi
done
