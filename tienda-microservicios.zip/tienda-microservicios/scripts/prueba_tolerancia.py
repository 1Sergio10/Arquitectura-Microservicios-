"""Prueba de extremo a extremo con los servicios reales corriendo.

1. Flujo normal: registrar cliente, consultar catálogo, crear pedido, cambiar estado.
2. Se apaga el servicio de productos.
3. Se verifica que clientes y pedidos siguen respondiendo y que crear un pedido
   falla rápido con 503 en lugar de quedarse colgado.
4. Se enciende productos de nuevo y el sistema se recupera solo.

Uso:  python scripts/prueba_tolerancia.py
"""
import json
import subprocess
import sys
import time
from pathlib import Path

import httpx

RAIZ = Path(__file__).resolve().parent.parent
PRODUCTOS, CLIENTES, PEDIDOS = "http://localhost:8001", "http://localhost:8002", "http://localhost:8003"


def mostrar(titulo: str, respuesta: httpx.Response, campos: list[str] | None = None) -> dict | list:
    cuerpo = respuesta.json()
    vista = cuerpo
    if campos and isinstance(cuerpo, dict):
        vista = {k: cuerpo[k] for k in campos if k in cuerpo}
    ms = respuesta.elapsed.total_seconds() * 1000
    print(f"\n>>> {titulo}")
    print(f"{respuesta.request.method} {respuesta.request.url.path}  ->  HTTP {respuesta.status_code}  ({ms:.0f} ms)")
    print(json.dumps(vista, ensure_ascii=False, indent=2))
    return cuerpo


def esperar(url: str, arriba: bool, segundos: float = 10) -> None:
    limite = time.time() + segundos
    while time.time() < limite:
        try:
            httpx.get(f"{url}/health", timeout=0.5)
            if arriba:
                return
        except httpx.HTTPError:
            if not arriba:
                return
        time.sleep(0.2)
    sys.exit(f"{url} no cambió de estado a tiempo")


def main() -> None:
    http = httpx.Client(timeout=5)
    print("=" * 70, "\nFASE 1 - FLUJO NORMAL CON LOS TRES SERVICIOS ACTIVOS\n" + "=" * 70)

    catalogo = mostrar("Consultar catálogo", http.get(f"{PRODUCTOS}/productos"))
    producto = catalogo[0]
    print(f"(se usará {producto['sku']} - {producto['nombre']})")

    cliente = mostrar("Registrar cliente", http.post(f"{CLIENTES}/clientes", json={
        "nombre": "Laura Gómez", "email": f"laura{int(time.time())}@correo.com",
        "documento": str(int(time.time())), "ciudad": "Bogotá"}), ["id", "nombre", "email"])

    pedido = mostrar("Registrar pedido", http.post(f"{PEDIDOS}/pedidos", headers={"Idempotency-Key": "demo-1"}, json={
        "cliente_id": cliente["id"], "items": [{"producto_id": producto["id"], "cantidad": 2}]}),
        ["id", "cliente_nombre", "total", "estado"])

    mostrar("Reintento con la misma Idempotency-Key (no duplica)",
            http.post(f"{PEDIDOS}/pedidos", headers={"Idempotency-Key": "demo-1"}, json={
                "cliente_id": cliente["id"], "items": [{"producto_id": producto["id"], "cantidad": 2}]}),
            ["id", "estado"])

    mostrar("Pagar pedido", http.patch(f"{PEDIDOS}/pedidos/{pedido['id']}/estado", json={"estado": "PAGADO"}))
    mostrar("Transición inválida PAGADO -> ENTREGADO",
            http.patch(f"{PEDIDOS}/pedidos/{pedido['id']}/estado", json={"estado": "ENTREGADO"}))

    print("\n" + "=" * 70, "\nFASE 2 - SE APAGA EL SERVICIO DE PRODUCTOS\n" + "=" * 70)
    subprocess.run([str(RAIZ / "scripts/detener.sh"), "productos"], check=True)
    esperar(PRODUCTOS, arriba=False)

    try:
        http.get(f"{PRODUCTOS}/health", timeout=1)
    except httpx.ConnectError:
        print("\n>>> GET /health en productos  ->  conexión rechazada (servicio apagado)")

    mostrar("Clientes sigue funcionando", http.get(f"{CLIENTES}/clientes/{cliente['id']}"), ["id", "nombre"])
    mostrar("Consultar pedido existente (no depende de productos)", http.get(f"{PEDIDOS}/pedidos/{pedido['id']}"),
            ["id", "total", "estado"])
    mostrar("Consultar estado del pedido", http.get(f"{PEDIDOS}/pedidos/{pedido['id']}/estado"))

    nuevo = {"cliente_id": cliente["id"], "items": [{"producto_id": producto["id"], "cantidad": 1}]}
    for intento in range(1, 5):
        mostrar(f"Crear pedido con productos caído (intento {intento})", http.post(f"{PEDIDOS}/pedidos", json=nuevo))
    mostrar("Estado de los circuitos", http.get(f"{PEDIDOS}/health/dependencias"))

    print("\n" + "=" * 70, "\nFASE 3 - SE ENCIENDE PRODUCTOS DE NUEVO\n" + "=" * 70)
    subprocess.run([str(RAIZ / "scripts/iniciar.sh"), "productos"], check=True)
    esperar(PRODUCTOS, arriba=True)
    catalogo = http.get(f"{PRODUCTOS}/productos").json()
    print("(esperando a que el circuito pase a SEMI_ABIERTO...)")
    time.sleep(15)
    nuevo["items"][0]["producto_id"] = catalogo[0]["id"]  # el catálogo en memoria se recrea con ids nuevos
    mostrar("Crear pedido tras la recuperación", http.post(f"{PEDIDOS}/pedidos", json=nuevo), ["id", "total", "estado"])
    mostrar("Estado de los circuitos", http.get(f"{PEDIDOS}/health/dependencias"))


if __name__ == "__main__":
    main()
