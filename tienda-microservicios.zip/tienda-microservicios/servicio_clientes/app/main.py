import logging
import os
import time
from uuid import UUID, uuid4

from fastapi import FastAPI, HTTPException, Query, Request, status

from .models import Cliente, ClienteCrear, ClientePublico
from .repository import ClienteDuplicado, RepositorioClientes

NOMBRE_SERVICIO = "servicio-clientes"

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s [%(name)s] %(message)s")
log = logging.getLogger(NOMBRE_SERVICIO)

app = FastAPI(
    title="Servicio de Clientes",
    version="1.0.0",
    description="Registra y consulta clientes. Es el único dueño de los datos personales.",
)
app.state.repo = RepositorioClientes()


@app.middleware("http")
async def trazabilidad(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    inicio = time.perf_counter()
    respuesta = await call_next(request)
    duracion_ms = (time.perf_counter() - inicio) * 1000
    respuesta.headers["X-Request-ID"] = request_id
    log.info("%s %s -> %s (%.1f ms) rid=%s", request.method, request.url.path, respuesta.status_code, duracion_ms, request_id)
    return respuesta


@app.get("/health", tags=["operación"])
def health() -> dict:
    return {"servicio": NOMBRE_SERVICIO, "estado": "ok"}


@app.post("/clientes", response_model=Cliente, status_code=status.HTTP_201_CREATED, tags=["clientes"])
def registrar_cliente(datos: ClienteCrear) -> Cliente:
    try:
        return app.state.repo.agregar(datos)
    except ClienteDuplicado as error:
        raise HTTPException(status.HTTP_409_CONFLICT, detail=f"Ya existe un cliente con ese {error.campo}")


@app.get("/clientes", response_model=list[Cliente], tags=["clientes"])
def listar_clientes(limite: int = Query(50, ge=1, le=200), desde: int = Query(0, ge=0)) -> list[Cliente]:
    return app.state.repo.listar(limite=limite, desde=desde)


@app.get("/clientes/{cliente_id}", response_model=Cliente, tags=["clientes"])
def obtener_cliente(cliente_id: UUID) -> Cliente:
    cliente = app.state.repo.obtener(cliente_id)
    if cliente is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail=f"Cliente {cliente_id} no existe")
    return cliente


@app.get("/clientes/{cliente_id}/resumen", response_model=ClientePublico, tags=["integración"])
def resumen_cliente(cliente_id: UUID) -> ClientePublico:
    """Endpoint pensado para otros servicios (pedidos). Entrega solo lo necesario."""
    cliente = obtener_cliente(cliente_id)
    return ClientePublico(id=cliente.id, nombre=cliente.nombre, email=cliente.email)
