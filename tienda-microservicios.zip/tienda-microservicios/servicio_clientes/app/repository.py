from datetime import datetime, timezone
from threading import Lock
from uuid import UUID, uuid4

from .models import Cliente, ClienteCrear


class ClienteDuplicado(Exception):
    def __init__(self, campo: str) -> None:
        super().__init__(campo)
        self.campo = campo


class RepositorioClientes:
    def __init__(self) -> None:
        self._items: dict[UUID, Cliente] = {}
        self._lock = Lock()

    def agregar(self, datos: ClienteCrear) -> Cliente:
        with self._lock:
            for existente in self._items.values():
                if existente.email == datos.email:
                    raise ClienteDuplicado("email")
                if existente.documento == datos.documento:
                    raise ClienteDuplicado("documento")
            cliente = Cliente(id=uuid4(), creado_en=datetime.now(timezone.utc), **datos.model_dump())
            self._items[cliente.id] = cliente
            return cliente

    def obtener(self, cliente_id: UUID) -> Cliente | None:
        return self._items.get(cliente_id)

    def listar(self, limite: int = 50, desde: int = 0) -> list[Cliente]:
        clientes = sorted(self._items.values(), key=lambda c: c.creado_en)
        return clientes[desde : desde + limite]
