from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ClienteCrear(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    nombre: str = Field(min_length=2, max_length=100, examples=["Laura Gómez"])
    email: str = Field(max_length=254, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$", examples=["laura@correo.com"])
    documento: str = Field(min_length=5, max_length=15, pattern=r"^\d+$", examples=["1020304050"])
    ciudad: str | None = Field(default=None, max_length=60, examples=["Bogotá"])

    @field_validator("email")
    @classmethod
    def normalizar_email(cls, valor: str) -> str:
        return valor.lower()


class Cliente(ClienteCrear):
    id: UUID
    creado_en: datetime


class ClientePublico(BaseModel):
    """Vista reducida que se entrega a otros servicios: no expone el documento."""

    id: UUID
    nombre: str
    email: str
