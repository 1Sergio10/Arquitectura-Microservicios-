import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.repository import RepositorioClientes


@pytest.fixture
def api():
    app.state.repo = RepositorioClientes()
    return TestClient(app)


NUEVO = {"nombre": "Laura Gómez", "email": "Laura@Correo.com", "documento": "1020304050", "ciudad": "Bogotá"}


def test_registrar_normaliza_email(api):
    respuesta = api.post("/clientes", json=NUEVO)
    assert respuesta.status_code == 201
    assert respuesta.json()["email"] == "laura@correo.com"


@pytest.mark.parametrize("cambio", [{"documento": "999999999"}, {"email": "otra@correo.com"}])
def test_no_permite_duplicados(api, cambio):
    api.post("/clientes", json=NUEVO)
    # Cambia uno de los dos campos únicos; el otro sigue repetido.
    assert api.post("/clientes", json={**NUEVO, **cambio}).status_code == 409


@pytest.mark.parametrize("campo, valor", [("email", "sin-arroba"), ("documento", "12ab"), ("nombre", "x")])
def test_validacion(api, campo, valor):
    assert api.post("/clientes", json={**NUEVO, campo: valor}).status_code == 422


def test_resumen_no_expone_documento(api):
    cliente_id = api.post("/clientes", json=NUEVO).json()["id"]
    resumen = api.get(f"/clientes/{cliente_id}/resumen").json()
    assert set(resumen) == {"id", "nombre", "email"}


def test_cliente_inexistente_404(api):
    assert api.get("/clientes/00000000-0000-0000-0000-000000000000/resumen").status_code == 404
